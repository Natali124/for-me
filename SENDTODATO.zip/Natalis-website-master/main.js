var clicked = 0;


function f1f1(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }

  if(clicked!=0)
  {
    clicked-=1;
    clear();
   
   }
   document.getElementById("G1D").classList.remove("info");
   document.getElementById("G1").classList.add("y");
   document.getElementById("G7").classList.add("related");
   document.getElementById("G15").classList.add("related");
   document.getElementById("2G12").classList.add("related");
   clicked+=1;

}
function f1f2(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
    if(clicked!=0)
    {
      clicked-=1;
      clear();
     
     }
     document.getElementById("G2D").classList.remove("info");
     document.getElementById("G2").classList.add("y");
     document.getElementById("G5").classList.add("prereq");
     document.getElementById("2G5").classList.add("prereq");
     document.getElementById("2G11").classList.add("related");
     clicked+=1;
  
}
function f1f3(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
    if(clicked!=0)
    {
      clicked-=1;
      clear();
     
     }
     document.getElementById("G3D").classList.remove("info");
     document.getElementById("G3").classList.add("y");
     document.getElementById("G6").classList.add("prereq");
     document.getElementById("G1").classList.add("prereq");
     clicked+=1;
  
}
function f1f4(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
    if(clicked!=0)
    {
      clicked-=1;
      clear();
     
     }
     document.getElementById("G4D").classList.remove("info");
     document.getElementById("G4").classList.add("y");
     document.getElementById("G7").classList.add("prereq");
     document.getElementById("G15").classList.add("prereq");
     document.getElementById("G13").classList.add("prereq");
     clicked+=1;
  
}
function f2f1(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
    if(clicked!=0)
    {
      clicked-=1;
      clear();
     
     }
     document.getElementById("G5D").classList.remove("info");
     document.getElementById("G5").classList.add("y");
     document.getElementById("G16").classList.add("related");
     document.getElementById("G11").classList.add("related");
     document.getElementById("G19").classList.add("related");
     document.getElementById("2G16").classList.add("related");
     clicked+=1;
  
}
function f2f2(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
      if(clicked!=0)
      {
        clicked-=1;
        clear();
       
       }
       document.getElementById("G6D").classList.remove("info");
       document.getElementById("G6").classList.add("y");
       document.getElementById("G9").classList.add("prereq");
       document.getElementById("2G9").classList.add("prereq");
       document.getElementById("2G15").classList.add("related");
       clicked+=1;
    
}
function f2f3(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
      if(clicked!=0)
      {
        clicked-=1;
        clear();
       
       }
       document.getElementById("G7D").classList.remove("info");
       document.getElementById("G7").classList.add("y");
       document.getElementById("G10").classList.add("prereq");
       document.getElementById("2G10").classList.add("prereq");
       clicked+=1;
    
}
function f2f4(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
      if(clicked!=0)
      {
        clicked-=1;
        clear();
       
       }
       document.getElementById("G8D").classList.remove("info");
       document.getElementById("G8").classList.add("y");
       document.getElementById("G5").classList.add("prereq");
       document.getElementById("G11").classList.add("prereq");
       document.getElementById("G19").classList.add("prereq");
       clicked+=1;
    
}
function f3f1(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
        if(clicked!=0)
        {
          clicked-=1;
          clear();
         
         }
         document.getElementById("G9D").classList.remove("info");
         document.getElementById("G9").classList.add("y");
         document.getElementById("G20").classList.add("related");
         document.getElementById("G15").classList.add("related");
         document.getElementById("2G3").classList.add("related");
         document.getElementById("2G20").classList.add("related");
         clicked+=1;
      
}
function f3f2(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
          if(clicked!=0)
          {
            clicked-=1;
            clear();
           
           }
           document.getElementById("G10D").classList.remove("info");
           document.getElementById("G10").classList.add("y");
           document.getElementById("G13").classList.add("prereq");
           document.getElementById("2G19").classList.add("related");
           clicked+=1;
        
}
function f3f3(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
    
          if(clicked!=0)
          {
            clicked-=1;
            clear();
           
           }
           document.getElementById("G11D").classList.remove("info");
           document.getElementById("G11").classList.add("y");
           document.getElementById("G14").classList.add("prereq");

           clicked+=1;
        
}
function f3f4(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
          if(clicked!=0)
          {
            clicked-=1;
            clear();
           
           }
           document.getElementById("G12D").classList.remove("info");
           document.getElementById("G12").classList.add("y");
           document.getElementById("G9").classList.add("prereq");
           clicked+=1;
        
}
function f4f1(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
    if(clicked!=0)
    {
      clicked-=1;
      clear();
     
     }
     document.getElementById("G13D").classList.remove("info");
     document.getElementById("G13").classList.add("y");
     document.getElementById("2G4").classList.add("related");
     document.getElementById("G19").classList.add("related");
     document.getElementById("2G7").classList.add("related");
     document.getElementById("3G4").classList.add("related");
     clicked+=1;
  
}
function f4f2(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
      if(clicked!=0)
      {
        clicked-=1;
        clear();
       
       }
       document.getElementById("G14D").classList.remove("info");
       document.getElementById("G14").classList.add("y");
       document.getElementById("G17").classList.add("prereq");
       document.getElementById("3G7").classList.add("related");
       document.getElementById("3G3").classList.add("related");
       clicked+=1;
    
}
function f4f3(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
      if(clicked!=0)
      {
        clicked-=1;
        clear();
       
       }
       document.getElementById("G15D").classList.remove("info");
       document.getElementById("G15").classList.add("y");
       document.getElementById("G18").classList.add("prereq");
       document.getElementById("3G8").classList.add("related");
       clicked+=1;
    
}
function f4f4(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
      if(clicked!=0)
      {
        clicked-=1;
        clear();
       
       }
       document.getElementById("G16D").classList.remove("info");
       document.getElementById("G16").classList.add("y");
       document.getElementById("G13").classList.add("prereq");
       document.getElementById("G19").classList.add("prereq");
       document.getElementById("2G7").classList.add("related");
       document.getElementById("3G7").classList.add("related");
       document.getElementById("2G5").classList.add("related");
       clicked+=1;
    
}
function f5f1(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
    if(clicked!=0)
    {
      clicked-=1;
      clear();
     
     }
     document.getElementById("G17D").classList.remove("info");
     document.getElementById("G17").classList.add("y");
     document.getElementById("2G8").classList.add("related");
     document.getElementById("2G11").classList.add("related");
     document.getElementById("2G20").classList.add("related");
     clicked+=1;
  
  }
function f5f2(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
      if(clicked!=0)
      {
        clicked-=1;
        clear();
       
       }
       document.getElementById("G18D").classList.remove("info");
       document.getElementById("G18").classList.add("y");
       document.getElementById("2G1").classList.add("prereq");
       document.getElementById("3G7").classList.add("related");
       clicked+=1;
    
}
function f5f3(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
      if(clicked!=0)
      {
        clicked-=1;
        clear();
       
       }
       document.getElementById("G19D").classList.remove("info");
       document.getElementById("G19").classList.add("y");
       document.getElementById("2G2").classList.add("prereq");
       document.getElementById("2G7").classList.add("related");
       document.getElementById("G17").classList.add("related");
       document.getElementById("2G5").classList.add("related");
       clicked+=1;
    
    }
function f5f4(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
      if(clicked!=0)
      {
        clicked-=1;
        clear();
       
       }
       document.getElementById("G20D").classList.remove("info");
       document.getElementById("G20").classList.add("y");
       document.getElementById("G17").classList.add("prereq");
       document.getElementById("2G3").classList.add("prereq");
       document.getElementById("2G11").classList.add("related");
       clicked+=1;
    
    }
function f6f1(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }

  if(clicked!=0)
  {
    clicked-=1;
    clear();
   
   }
   document.getElementById("2G1D").classList.remove("info");
   document.getElementById("2G1").classList.add("y");
   document.getElementById("2G7").classList.add("related");
   document.getElementById("2G15").classList.add("related");
   document.getElementById("3G12").classList.add("related");
   clicked+=1;

}
function f6f2(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
    if(clicked!=0)
    {
      clicked-=1;
      clear();
     
     }
     document.getElementById("2G2D").classList.remove("info");
     document.getElementById("2G2").classList.add("y");
     document.getElementById("2G5").classList.add("prereq");
     document.getElementById("3G11").classList.add("related");
     clicked+=1;
  
}
function f6f3(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
    if(clicked!=0)
    {
      clicked-=1;
      clear();
     
     }
     document.getElementById("2G3D").classList.remove("info");
     document.getElementById("2G3").classList.add("y");
     document.getElementById("2G6").classList.add("prereq");
     clicked+=1;
  
}
function f6f4(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
    if(clicked!=0)
    {
      clicked-=1;
      clear();
     
     }
     document.getElementById("2G4D").classList.remove("info");
     document.getElementById("2G4").classList.add("y");
     document.getElementById("2G1").classList.add("prereq");
     clicked+=1;
  
}
function f7f1(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
    if(clicked!=0)
    {
      clicked-=1;
      clear();
     
     }
     document.getElementById("2G5D").classList.remove("info");
     document.getElementById("2G5").classList.add("y");
     document.getElementById("2G16").classList.add("related");
     document.getElementById("2G19").classList.add("related");
     document.getElementById("3G16").classList.add("related");
     clicked+=1;
  
}
function f7f2(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
      if(clicked!=0)
      {
        clicked-=1;
        clear();
       
       }
       document.getElementById("2G6D").classList.remove("info");
       document.getElementById("2G6").classList.add("y");
       document.getElementById("2G9").classList.add("prereq");
       document.getElementById("2G14").classList.add("related");
       document.getElementById("3G15").classList.add("related");
       clicked+=1;
    
}
function f7f3(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
      if(clicked!=0)
      {
        clicked-=1;
        clear();
       
       }
       document.getElementById("2G7D").classList.remove("info");
       document.getElementById("2G7").classList.add("y");
       document.getElementById("2G10").classList.add("prereq");
       document.getElementById("2G5").classList.add("related");
       document.getElementById("2G13").classList.add("related");
       clicked+=1;
    
}
function f7f4(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
      if(clicked!=0)
      {
        clicked-=1;
        clear();
       
       }
       document.getElementById("2G8D").classList.remove("info");
       document.getElementById("2G8").classList.add("y");
       document.getElementById("2G6").classList.add("prereq");
       clicked+=1;
    
}
function f8f1(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
        if(clicked!=0)
        {
          clicked-=1;
          clear();
         
         }
         document.getElementById("2G9D").classList.remove("info");
         document.getElementById("2G9").classList.add("y");
         document.getElementById("2G20").classList.add("related");
         document.getElementById("3G3").classList.add("related");
         document.getElementById("3G20").classList.add("related");
         clicked+=1;
      
}
function f8f2(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
          if(clicked!=0)
          {
            clicked-=1;
            clear();
           
           }
           document.getElementById("2G10D").classList.remove("info");
           document.getElementById("2G10").classList.add("y");
           document.getElementById("2G13").classList.add("prereq");
           document.getElementById("2G18").classList.add("related");
           document.getElementById("3G19").classList.add("related");
           clicked+=1;
        
}
function f8f3(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
    
          if(clicked!=0)
          {
            clicked-=1;
            clear();
           
           }
           document.getElementById("2G11D").classList.remove("info");
           document.getElementById("2G11").classList.add("y");
           document.getElementById("2G14").classList.add("prereq");
           document.getElementById("2G19").classList.add("related");
           document.getElementById("2G9").classList.add("related");

           clicked+=1;
        
}
function f8f4(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
          if(clicked!=0)
          {
            clicked-=1;
            clear();
           
           }
           document.getElementById("2G12D").classList.remove("info");
           document.getElementById("2G12").classList.add("y");
           document.getElementById("2G9").classList.add("prereq");
           document.getElementById("2G15").classList.add("related");
           clicked+=1;
        
}
function f9f1(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
    if(clicked!=0)
    {
      clicked-=1;
      clear();
     
     }
     document.getElementById("2G13D").classList.remove("info");
     document.getElementById("2G13").classList.add("y");
     document.getElementById("2G19").classList.add("related");
     document.getElementById("3G7").classList.add("related");
     clicked+=1;
  
}
function f9f2(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
      if(clicked!=0)
      {
        clicked-=1;
        clear();
       
       }
       document.getElementById("2G14D").classList.remove("info");
       document.getElementById("2G14").classList.add("y");
       document.getElementById("2G17").classList.add("prereq");
       clicked+=1;
    
}
function f9f3(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
      if(clicked!=0)
      {
        clicked-=1;
        clear();
       
       }
       document.getElementById("2G15D").classList.remove("info");
       document.getElementById("2G15").classList.add("y");
       document.getElementById("2G18").classList.add("prereq");
       document.getElementById("3G3").classList.add("related");
       document.getElementById("3G1").classList.add("related");
       document.getElementById("G8").classList.add("related");
       clicked+=1;
    
}
function f9f4(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
      if(clicked!=0)
      {
        clicked-=1;
        clear();
       
       }
       document.getElementById("2G16D").classList.remove("info");
       document.getElementById("2G16").classList.add("y");
       document.getElementById("2G13").classList.add("prereq");
       document.getElementById("2G19").classList.add("related");
       clicked+=1;
    
}
function f10f1(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
    if(clicked!=0)
    {
      clicked-=1;
      clear();
     
     }
     document.getElementById("2G17D").classList.remove("info");
     document.getElementById("2G17").classList.add("y");
     document.getElementById("3G8").classList.add("related");
     document.getElementById("3G11").classList.add("related");
     document.getElementById("3G20").classList.add("related");
     clicked+=1;
  
  }
function f10f2(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
      if(clicked!=0)
      {
        clicked-=1;
        clear();
       
       }
       document.getElementById("2G18D").classList.remove("info");
       document.getElementById("2G18").classList.add("y");
       document.getElementById("3G1").classList.add("prereq");
       document.getElementById("3G6").classList.add("related");
       document.getElementById("G7").classList.add("related");
       clicked+=1;
    
}
function f10f2h(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
      if(clicked!=0)
      {
        clicked-=1;
        clear();
       
       }
       document.getElementById("2G18hD").classList.remove("info");
       document.getElementById("2G18h").classList.add("y");
       document.getElementById("3G1").classList.add("prereq");
       document.getElementById("3G6").classList.add("related");
       document.getElementById("G7").classList.add("related");
       clicked+=1;
    
}
function f10f3(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
      if(clicked!=0)
      {
        clicked-=1;
        clear();
       
       }
       document.getElementById("2G19D").classList.remove("info");
       document.getElementById("2G19").classList.add("y");
       document.getElementById("3G2").classList.add("prereq");
       document.getElementById("3G7").classList.add("related");
       document.getElementById("2G17").classList.add("related");
       clicked+=1;
    
    }
function f10f4(x){
  if(document.getElementById(x).classList!="info")
  {
    clear();
    clicked=0;
    return;
  }
      if(clicked!=0)
      {
        clicked-=1;
        clear();
       
       }
       document.getElementById("2G20D").classList.remove("info");
       document.getElementById("2G20").classList.add("y");
       document.getElementById("2G17").classList.add("prereq");
       document.getElementById("3G3").classList.add("related");
       document.getElementById("3G11").classList.add("related");
       clicked+=1;
    
    }




function clear (){
    document.getElementById("G1D").classList.add("info");
    document.getElementById("G7D").classList.add("info");
    document.getElementById("G10D").classList.add("info");
    document.getElementById("G11D").classList.add("info");
    document.getElementById("G19D").classList.add("info");
    document.getElementById("G2D").classList.add("info");
    document.getElementById("G3D").classList.add("info");
    document.getElementById("G8D").classList.add("info");
    document.getElementById("G9D").classList.add("info");
    document.getElementById("G20D").classList.add("info");
    document.getElementById("G4D").classList.add("info");
    document.getElementById("G5D").classList.add("info");
    document.getElementById("G12D").classList.add("info");
    document.getElementById("G17D").classList.add("info");
    document.getElementById("G18D").classList.add("info");
    document.getElementById("G6D").classList.add("info");
    document.getElementById("G13D").classList.add("info");
    document.getElementById("G14D").classList.add("info");
    document.getElementById("G15D").classList.add("info");
    document.getElementById("G16D").classList.add("info");
    document.getElementById("2G2D").classList.add("info");
    document.getElementById("2G18hD").classList.add("info");
    document.getElementById("2G8D").classList.add("info");
    document.getElementById("2G10D").classList.add("info");
    document.getElementById("2G13D").classList.add("info");
    document.getElementById("2G20D").classList.add("info");
    document.getElementById("2G1D").classList.add("info");
    document.getElementById("2G4D").classList.add("info");
    document.getElementById("2G7D").classList.add("info");
    document.getElementById("2G9D").classList.add("info");
    document.getElementById("2G19D").classList.add("info");
    document.getElementById("2G3D").classList.add("info");
    document.getElementById("2G6D").classList.add("info");
    document.getElementById("2G11D").classList.add("info");
    document.getElementById("2G17D").classList.add("info");
    document.getElementById("2G18D").classList.add("info");
    document.getElementById("2G5D").classList.add("info");
    document.getElementById("2G12D").classList.add("info");
    document.getElementById("2G14D").classList.add("info");
    document.getElementById("2G15D").classList.add("info");
    document.getElementById("2G16D").classList.add("info");
    document.getElementById("3G2D").classList.add("info");
    document.getElementById("3G18hD").classList.add("info");
    document.getElementById("3G8D").classList.add("info");
    document.getElementById("3G10D").classList.add("info");
    document.getElementById("3G13D").classList.add("info");
    document.getElementById("3G20D").classList.add("info");
    document.getElementById("3G1D").classList.add("info");
    document.getElementById("3G4D").classList.add("info");
    document.getElementById("3G7D").classList.add("info");
    document.getElementById("3G9D").classList.add("info");
    document.getElementById("3G19D").classList.add("info");
    document.getElementById("3G3D").classList.add("info");
    document.getElementById("3G6D").classList.add("info");
    document.getElementById("3G11hD").classList.add("info");
    document.getElementById("3G11D").classList.add("info");
    document.getElementById("3G17D").classList.add("info");
    document.getElementById("3G18D").classList.add("info");
    document.getElementById("3G5D").classList.add("info");
    document.getElementById("3G12D").classList.add("info");
    document.getElementById("3G14D").classList.add("info");
    document.getElementById("3G15D").classList.add("info");
    document.getElementById("3G16D").classList.add("info");
    document.getElementById("G1").classList.remove("prereq") 
    document.getElementById("G7").classList.remove("prereq");
    document.getElementById("G10").classList.remove("prereq");
    document.getElementById("G11").classList.remove("prereq");
    document.getElementById("G19").classList.remove("prereq");
    document.getElementById("G2").classList.remove("prereq");
    document.getElementById("G3").classList.remove("prereq");
    document.getElementById("G8").classList.remove("prereq");
    document.getElementById("G9").classList.remove("prereq");
    document.getElementById("G20").classList.remove("prereq");
    document.getElementById("G4").classList.remove("prereq");
    document.getElementById("G5").classList.remove("prereq");
    document.getElementById("G12").classList.remove("prereq");
    document.getElementById("G17").classList.remove("prereq");
    document.getElementById("G18").classList.remove("prereq");
    document.getElementById("G6").classList.remove("prereq");
    document.getElementById("G13").classList.remove("prereq");
    document.getElementById("G14").classList.remove("prereq");
    document.getElementById("G15").classList.remove("prereq");
    document.getElementById("G16").classList.remove("prereq");
    document.getElementById("2G2").classList.remove("prereq");
    document.getElementById("2G18h").classList.remove("prereq");
    document.getElementById("2G8").classList.remove("prereq");
    document.getElementById("2G10").classList.remove("prereq");
    document.getElementById("2G13").classList.remove("prereq");
    document.getElementById("2G20").classList.remove("prereq");
    document.getElementById("2G1").classList.remove("prereq");
    document.getElementById("2G4").classList.remove("prereq");
    document.getElementById("2G7").classList.remove("prereq");
    document.getElementById("2G9").classList.remove("prereq");
    document.getElementById("2G19").classList.remove("prereq");
    document.getElementById("2G3").classList.remove("prereq");
    document.getElementById("2G6").classList.remove("prereq");
    document.getElementById("2G11").classList.remove("prereq");
    document.getElementById("2G17").classList.remove("prereq");
    document.getElementById("2G18").classList.remove("prereq");
    document.getElementById("2G5").classList.remove("prereq");
    document.getElementById("2G12").classList.remove("prereq");
    document.getElementById("2G14").classList.remove("prereq");
    document.getElementById("2G15").classList.remove("prereq");
    document.getElementById("2G16").classList.remove("prereq");
    document.getElementById("3G2").classList.remove("prereq");
    document.getElementById("3G18h").classList.remove("prereq");
    document.getElementById("3G8").classList.remove("prereq");
    document.getElementById("3G10").classList.remove("prereq");
    document.getElementById("3G13").classList.remove("prereq");
    document.getElementById("3G20").classList.remove("prereq");
    document.getElementById("3G1").classList.remove("prereq");
    document.getElementById("3G4").classList.remove("prereq");
    document.getElementById("3G7").classList.remove("prereq");
    document.getElementById("3G9").classList.remove("prereq");
    document.getElementById("3G19").classList.remove("prereq");
    document.getElementById("3G3").classList.remove("prereq");
    document.getElementById("3G6").classList.remove("prereq");
    document.getElementById("3G11h").classList.remove("prereq");
    document.getElementById("3G11").classList.remove("prereq");
    document.getElementById("3G17").classList.remove("prereq");
    document.getElementById("3G18").classList.remove("prereq");
    document.getElementById("3G5").classList.remove("prereq");
    document.getElementById("3G12").classList.remove("prereq");
    document.getElementById("3G14").classList.remove("prereq");
    document.getElementById("3G15").classList.remove("prereq");
    document.getElementById("3G16").classList.remove("prereq");
    document.getElementById("G1").classList.remove("related") 
    document.getElementById("G7").classList.remove("related");
    document.getElementById("G10").classList.remove("related");
    document.getElementById("G11").classList.remove("related");
    document.getElementById("G19").classList.remove("related");
    document.getElementById("G2").classList.remove("related");
    document.getElementById("G3").classList.remove("related");
    document.getElementById("G8").classList.remove("related");
    document.getElementById("G9").classList.remove("related");
    document.getElementById("G20").classList.remove("related");
    document.getElementById("G4").classList.remove("related");
    document.getElementById("G5").classList.remove("related");
    document.getElementById("G12").classList.remove("related");
    document.getElementById("G17").classList.remove("related");
    document.getElementById("G18").classList.remove("related");
    document.getElementById("G6").classList.remove("related");
    document.getElementById("G13").classList.remove("related");
    document.getElementById("G14").classList.remove("related");
    document.getElementById("G15").classList.remove("related");
    document.getElementById("G16").classList.remove("related");
    document.getElementById("2G2").classList.remove("related");
    document.getElementById("2G18h").classList.remove("related");
    document.getElementById("2G8").classList.remove("related");
    document.getElementById("2G10").classList.remove("related");
    document.getElementById("2G13").classList.remove("related");
    document.getElementById("2G20").classList.remove("related");
    document.getElementById("2G1").classList.remove("related");
    document.getElementById("2G4").classList.remove("related");
    document.getElementById("2G7").classList.remove("related");
    document.getElementById("2G9").classList.remove("related");
    document.getElementById("2G19").classList.remove("related");
    document.getElementById("2G3").classList.remove("related");
    document.getElementById("2G6").classList.remove("related");
    document.getElementById("2G11").classList.remove("related");
    document.getElementById("2G17").classList.remove("related");
    document.getElementById("2G18").classList.remove("related");
    document.getElementById("2G5").classList.remove("related");
    document.getElementById("2G12").classList.remove("related");
    document.getElementById("2G14").classList.remove("related");
    document.getElementById("2G15").classList.remove("related");
    document.getElementById("2G16").classList.remove("related");
    document.getElementById("3G2").classList.remove("related");
    document.getElementById("3G18h").classList.remove("related");
    document.getElementById("3G8").classList.remove("related");
    document.getElementById("3G10").classList.remove("related");
    document.getElementById("3G13").classList.remove("related");
    document.getElementById("3G20").classList.remove("related");
    document.getElementById("3G1").classList.remove("related");
    document.getElementById("3G4").classList.remove("related");
    document.getElementById("3G7").classList.remove("related");
    document.getElementById("3G9").classList.remove("related");
    document.getElementById("3G19").classList.remove("related");
    document.getElementById("3G3").classList.remove("related");
    document.getElementById("3G6").classList.remove("related");
    document.getElementById("3G11h").classList.remove("related");
    document.getElementById("3G11").classList.remove("related");
    document.getElementById("3G17").classList.remove("related");
    document.getElementById("3G18").classList.remove("related");
    document.getElementById("3G5").classList.remove("related");
    document.getElementById("3G12").classList.remove("related");
    document.getElementById("3G14").classList.remove("related");
    document.getElementById("3G15").classList.remove("related");
    document.getElementById("3G16").classList.remove("related");
    document.getElementById("G1").classList.remove("y") 
    document.getElementById("G7").classList.remove("y");
    document.getElementById("G10").classList.remove("y");
    document.getElementById("G11").classList.remove("y");
    document.getElementById("G19").classList.remove("y");
    document.getElementById("G2").classList.remove("y");
    document.getElementById("G3").classList.remove("y");
    document.getElementById("G8").classList.remove("y");
    document.getElementById("G9").classList.remove("y");
    document.getElementById("G20").classList.remove("y");
    document.getElementById("G4").classList.remove("y");
    document.getElementById("G5").classList.remove("y");
    document.getElementById("G12").classList.remove("y");
    document.getElementById("G17").classList.remove("y");
    document.getElementById("G18").classList.remove("y");
    document.getElementById("G6").classList.remove("y");
    document.getElementById("G13").classList.remove("y");
    document.getElementById("G14").classList.remove("y");
    document.getElementById("G15").classList.remove("y");
    document.getElementById("G16").classList.remove("y");
    document.getElementById("2G2").classList.remove("y");
    document.getElementById("2G18h").classList.remove("y");
    document.getElementById("2G8").classList.remove("y");
    document.getElementById("2G10").classList.remove("y");
    document.getElementById("2G13").classList.remove("y");
    document.getElementById("2G20").classList.remove("y");
    document.getElementById("2G1").classList.remove("y");
    document.getElementById("2G4").classList.remove("y");
    document.getElementById("2G7").classList.remove("y");
    document.getElementById("2G9").classList.remove("y");
    document.getElementById("2G19").classList.remove("y");
    document.getElementById("2G3").classList.remove("y");
    document.getElementById("2G6").classList.remove("y");
    document.getElementById("2G11").classList.remove("y");
    document.getElementById("2G17").classList.remove("y");
    document.getElementById("2G18").classList.remove("y");
    document.getElementById("2G5").classList.remove("y");
    document.getElementById("2G12").classList.remove("y");
    document.getElementById("2G14").classList.remove("y");
    document.getElementById("2G15").classList.remove("y");
    document.getElementById("2G16").classList.remove("y");
    document.getElementById("3G2").classList.remove("y");
    document.getElementById("3G18h").classList.remove("y");
    document.getElementById("3G8").classList.remove("y");
    document.getElementById("3G10").classList.remove("y");
    document.getElementById("3G13").classList.remove("y");
    document.getElementById("3G20").classList.remove("y");
    document.getElementById("3G1").classList.remove("y");
    document.getElementById("3G4").classList.remove("y");
    document.getElementById("3G7").classList.remove("y");
    document.getElementById("3G9").classList.remove("y");
    document.getElementById("3G19").classList.remove("y");
    document.getElementById("3G3").classList.remove("y");
    document.getElementById("3G6").classList.remove("y");
    document.getElementById("3G11h").classList.remove("y");
    document.getElementById("3G11").classList.remove("y");
    document.getElementById("3G17").classList.remove("y");
    document.getElementById("3G18").classList.remove("y");
    document.getElementById("3G5").classList.remove("y");
    document.getElementById("3G12").classList.remove("y");
    document.getElementById("3G14").classList.remove("y");
    document.getElementById("3G15").classList.remove("y");
    document.getElementById("3G16").classList.remove("y");
   
    
   
}
